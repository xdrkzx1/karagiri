<div className="wizzy-search-modal wizzy-search-mini-block d-none" id="wizzy-search-modal-mini">
    <div className="wizzy-search-modal-overlay"></div>
    <div className="wizzy-search-modal-content">
        <form method="get" className="wizzy-search-form" id="wizzy-search-form">
            <div className="wizzy-search-form-wrapper">
                <div className="wizzy-search-form-mobile-wrapper"></div>
                <div className="wizzy-search-form">
                    <div className="wizzy-form-modal-elements">
                        <div className="wizzy-search-modal-input">
                            <div className="wizzy-search-icon"></div>
                            <input type="search" className="wizzy-search-input" id="wizzy-search-input"
                                   autoComplete="off" placeholder="Search"/>
                        </div>
                        <div className="wizzy-search-modal-close-icon"></div>
                    </div>
                    <a href="#" className="wizzy-search-glass">
                        <span className="wizzy-icon"></span>
                    </a>
                    <a href="#" className="wizzy-search-back">
                        <span className="wizzy-icon"></span>
                    </a>
                    <a href="#" className="wizzy-search-clear">
                        <span className="wizzy-icon"></span>
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>