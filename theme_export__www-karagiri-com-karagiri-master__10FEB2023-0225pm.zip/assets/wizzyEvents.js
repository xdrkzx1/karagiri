$(window).ready(function() {
  
  
  $('.nav-standard-top-area-search-input').attr('autocomplete','off');
  
   $('.nav-search-dialog-form').attr('action','/pages/search');
  
  $('.nav-standard-top-area-search').attr('action','/pages/search');
  
  
  
});



const showFilter=()=>{

   
  	

  
  let cssOptions={
    left:"0"
  }
    $('.wizzy-search-filters-left').css('display','block!important');
    $('.wizzy-filters-bg').css('display','block!important');
    
    
  
	$('.wizzy-filters-header').css(cssOptions);
  
  	$('.wizzy-search-filters-left-wrapper').css(cssOptions)
  
	$('.smile-launcher-frame').css('display','none');
  

};


const hideFilter=()=>{
     $('body').removeClass('no-scroll');
  $('.smile-launcher-frame').css('display','block');

}
;


$('body').on('click','#wizzy-filter-close-button',function(e){
    e.preventDefault();
  
  	$('.wizzy-filters-bg').trigger('click');
  
  
  });

 

$('body').on('click','#wizzy-filter-btn',function(e){
    e.preventDefault();
  	showFilter();
  });


$('body').on('click','.wizzy-filters-bg',function(e){
  
  hideFilter();

})

window.wizzyConfig.events.registerEvent(window.wizzyConfig.events.allowedEvents.PRODUCTS_RESULTS_RENDERED, function(payload) {
  $('body').removeClass('no-scroll');
  hideFilter();
  console.log('payload',payload);
  $('[name="q"]').val('');
  return payload;
});



$(document).on("click",".wizzy-facet-list-item",function(){

$('body').removeClass('no-scroll');
  
  
});


$(document).on("click",".wizzy-filters-clear-all",function(){
  	$("html, body").animate({ scrollTop: 0 }, "slow");
  
});




var filterClicked=false;
window.wizzyConfig.events.registerEvent(window.wizzyConfig.events.allowedEvents.VIEW_RENDERED, function(payload) {
   $('body').removeClass('no-scroll');
  hideFilter();
     if($('#navbarStickyDesktop').hasClass('nav-sticky')){
       		 $('.wizzy-autocomplete-wrapper').addClass('wizzy-sticky');     
            }else{
             $('.wizzy-autocomplete-wrapper').removeClass('wizzy-sticky');
            }
  if(filterClicked){
  $('#wizzy-filter-btn').trigger('click');
    filterClicked=false;
  }
    return payload;
  
});

window.wizzyConfig.events.registerEvent(window.wizzyConfig.events.allowedEvents.AFTER_FILTER_ITEM_CLICKED, function(payload) {

  filterClicked=true;
  	 	$('body').removeClass('no-scroll');
  	$("html, body").animate({ scrollTop: 0 }, "slow");
  
  
    return payload;
  
});





// Select the node that will be observed for mutations
const targetNode = document.getElementById('navbarStickyDesktop');

// Options for the observer (which mutations to observe)
const config = { attributes: true, childList: true, subtree: true };

// Callback function to execute when mutations are observed
const callback = function(mutationList, observer) {
    // Use traditional 'for loops' for IE 11
  
    for(const mutation of mutationList) {
        
        if (mutation.type === 'attributes') {
          
          if(mutation.attributeName=='class'){
            
            if($('#navbarStickyDesktop').hasClass('nav-sticky')){
              
            $('.wizzy-autocomplete-wrapper').addClass('wizzy-sticky');
            
            }else{
            
             $('.wizzy-autocomplete-wrapper').removeClass('wizzy-sticky');
            }
            
          }
          
        }
    }
};

// Create an observer instance linked to the callback function
const observer = new MutationObserver(callback);

// Start observing the target node for configured mutations
observer.observe(targetNode, config);



$("body").on("click",".lin.lin-magnifier.popup-text.search-modal-popup.nav-container-action.st-search-ico",function(event){
console.log('===Wizzy Mobile Search Btn Clicked');
  $("body").addClass('wizzy-mobile-search');
  $("body").removeClass('y-hid');
  $(".wizzy-search-form-mobile-wrapper").addClass('wizzy-show');
	$('body').addClass('no-scroll');
});


$("body").on("click",".wizzy-search-form-mobile-overlay",function(event){

  $(".wizzy-show").removeClass('wizzy-show');
  	$('body').removeClass('no-scroll');
    $(".wizzy-search-form-mobile-wrapper").removeClass('wizzy-show');

});


$("body").on("submit","#wizzy-search-form-mobile-form",function(event){
  $(".wizzy-show").removeClass('wizzy-show');
  	$('body').removeClass('no-scroll');
  $(".wizzy-search-form-mobile-wrapper").removeClass('wizzy-show');
  
});


$("body").on("submit",".nav-standard-top-area-search",function(event){
 
  
  	$("#wizzy-autocomplete-wrapper-1").css({display:"none"});
  
  	$("html, body").animate({ scrollTop: 0 }, "slow");
});


$("body").on("click","#wizzy-autocomplete-wrapper-1",function(event){
  $(".wizzy-show").removeClass('wizzy-show');
  	$('body').removeClass('no-scroll');
  $(".wizzy-search-form-mobile-wrapper").removeClass('wizzy-show');
});

$("body").on("click",".wizzy-search-clear",function(event){
  
  $('#wizzy-mobile-serach-input').val('');
  
});


$("body").on("click",".wizzy-search-back",function(event){
  $(".wizzy-show").removeClass('wizzy-show');
  	$('body').removeClass('no-scroll');
  $(".wizzy-search-form-mobile-wrapper").removeClass('wizzy-show');
  
});




