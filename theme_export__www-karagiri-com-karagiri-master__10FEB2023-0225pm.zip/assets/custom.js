$('.offer_slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  dots: true,
  autoplay: true,
  arrows: false,
  autoplaySpeed: 3000,
});

$('.codecopy-loader').hide();
$(document).on('click', 'div.discount-code-snippet .discount-code', function(e) {
  e.preventDefault();
  var current = $(this).siblings('.discount-success-msg');
  var curr = $(this).children('span');
  var discount_code = $(this).data('id');
  var loaderclass = $(this).siblings('.codecopy-loader');
  $.ajax({
      url: `/discount/${discount_code}`,
      method: 'GET',
      beforeSend: function() {
          $(loaderclass).show();
          $(current).hide();
      },
      success: function() {
          $(loaderclass).hide();
          $(current).show();
          $(current).html('Code applied');
          $(curr).removeClass('before-apply');
          $(curr).addClass('after-apply');
      }
  })
});


// Accordian
$(document).on('click','.cust-accordion .acco-title',function(e) {
  e.preventDefault();
  $(this).toggleClass('active').siblings('.acco-content').slideToggle();
})