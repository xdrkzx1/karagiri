
$(document).ready(function(){
  var country = '';
  if(window.localStorage.getItem('country') != null){
   country = JSON.parse(window.localStorage.getItem('country')).country;
  }else{
    country = 'IN';
  }
  console.log(country);


  $(document).on('click', '.quick-view-btn', function(){
    fetch(`https://www.karagiri.com/${$(this).attr('href')}.json`)
    .then((response) => response.json())
    .then((response) => {
      console.log(response);
      for(var i = 0; i < response.product.variants.length; i++){
        if(response.product.variants[i].title == country){
          console.log('country matched..!!');
          $('ul.product-item-caption-price').html(`
            <li class="product-item-caption-price-list">
              <span class="money" data-money="1657000">
                <span class="money">₹ ${response.product.variants[i].compare_at_price}</span>
              </span>
            </li>
            <li class="product-item-caption-price-current">
              <span class="money" data-money="497100">
                <span class="money" data-product-id="${response.product.id}">
                  <span class="money">₹ ${response.product.variants[i].price}</span>
                </span>
              </span>
            </li>
          `);
          changeSelectValue(response.product.variants[i].id, country);
        }
      }
    })
  });
  // if(!window.localStorage.getItem('user')){
  //   window
  //   .fetch("https://ip2c.org/self")
  //   .then((response) => response.text())
  //   .then((data) => {
  //     console.log(data);
  //     var country_data = String(data).split(";");
  //     var country = country_data[1];
  //     window.localStorage.setItem('country', country);
  //   })
  // }
  if(__st.p == 'collection' || __st.p == 'home'){
    // window
    // .fetch("https://ip2c.org/self")
    // .then((response) => response.text())
    // .then((data) => {
    //   console.log(data);
    //   var country_data = String(data).split(";");
    //   var country = country_data[1];
      $('a.product-thumb-href').each(function(){
        console.log(country);
        var count = 0;
        fetch(`https://www.karagiri.com${$(this).attr('href')}.json`)
        .then(res=>res.json())
        .then(response=>{
          // console.log(response);
          for(var i = 0; i < response.product.variants.length; i++){
            if(country == 'IN'){
              if(response.product.variants[i].title == 'IN'){
                count++;
                $(`ul.product-thumb-caption-price.${response.product.handle}`).html(`
                  <li class="product-thumb-caption-price-list">
                    <span class="compare-price money">
                      <span class="money" data-original-value="${response.product.variants[i].compare_at_price}" data-inr="Rs. ${response.product.variants[i].compare_at_price}">
                        Rs. ${response.product.variants[i].compare_at_price}
                      </span>
                    </span>
                  </li>
                  <li class="product-thumb-caption-price-current">
                    <span class="money">
                      <span class="money" data-product-id="${response.product.id}">
                        <span class="money" data-original-value="${response.product.variants[i].price}" data-inr="Rs. ${response.product.variants[i].price}">
                          Rs. ${response.product.variants[i].price}
                        </span>
                      </span>
                    </span>
                  </li>
                `)
              }
            }
            if(country != 'IN'){
              // console.log('if called');
              // console.log(response);
              if(response.product.variants[i].title == 'OTHER'){
                // console.log('if other called');
                count++;
                $(`ul.product-thumb-caption-price.${response.product.handle}`).html(`
                  <li class="product-thumb-caption-price-list">
                    <span class="compare-price money">
                      <span class="money" data-original-value="${response.product.variants[i].compare_at_price}" data-inr="Rs. ${response.product.variants[i].compare_at_price}">
                        Rs. ${response.product.variants[i].compare_at_price}
                      </span>
                    </span>
                  </li>
                  <li class="product-thumb-caption-price-current">
                    <span class="money">
                      <span class="money" data-product-id="${response.product.id}">
                        <span class="money" data-original-value="${response.product.variants[i].price}" data-inr="Rs. ${response.product.variants[i].price}">
                          Rs. ${response.product.variants[i].price}
                        </span>
                      </span>
                    </span>
                  </li>
                `)
              }
            }
          }
          if(count == 0){
            $(`ul.product-thumb-caption-price.${response.product.handle} .product-thumb-caption-price-list`).removeAttr('style');
            $(`ul.product-thumb-caption-price.${response.product.handle} .product-thumb-caption-price-current`).removeAttr('style');
          }
        });
      });
    // })
  }

  
  if(__st.p == 'product'){
    var url = __st.pageurl.split("?")[0];
    fetch(`https://${url}.json`)
    .then(res=>res.json())
    .then(result=>{
      console.log(result);
      for(var i = 0; i < result.product.variants.length; i++){
        if(country == 'IN'){
          if(result.product.variants[i].title == 'IN'){
            var variant_id = result.product.variants[i].id;
            console.log(result.product.variants[i].id);
            window.history.pushState({ path: window.location.href }, '', `?variant=${result.product.variants[i].id}`);
            $(`.product-item-caption-price.${result.product.handle}`).html(`
              <li id="ProductPrice-product-template ${result.product.handle}" class="product-item-caption-price-current">
                <span class="money">
                  <span class="money" data-product-id="${result.product.id}">
                    <span class="money">
                      ₹ ${result.product.variants[i].price}
                    </span>
                  </span>
                </span>
              </li>
              <li id="ComparePrice-product-template ${result.product.handle}" class="product-item-caption-price-list"><span class="money">
                  <span class="bold-compare-at-money" data-product-id="${result.product.id}">
                    <span class="money">
                      ₹ ${result.product.variants[i].compare_at_price}
                    </span>
                  </span>
                </span>
              </li>
            `);
            changeSelectValue(result.product.variants[i].id, country)
            // console.log('success..!!')
            // changeSelectValue(variant_id)
            // location.reload();
          }
        }
        else{
          if(result.product.variants[i].title == 'OTHER'){
            var variant_id = result.product.variants[i].id;
            console.log(result.product.variants[i].id);
            window.history.pushState({ path: window.location.href }, '', `?variant=${result.product.variants[i].id}`);
            $(`.product-item-caption-price.${result.product.handle}`).html(`
              <li id="ProductPrice-product-template ${result.product.handle}" class="product-item-caption-price-current">
                <span class="money">
                  <span class="money" data-product-id="${result.product.id}">
                    <span class="money">
                      ₹ ${result.product.variants[i].price}
                    </span>
                  </span>
                </span>
              </li>
              <li id="ComparePrice-product-template ${result.product.handle}" class="product-item-caption-price-list"><span class="money">
                  <span class="bold-compare-at-money" data-product-id="${result.product.id}">
                    <span class="money">
                      ₹ ${result.product.variants[i].compare_at_price}
                    </span>
                  </span>
                </span>
              </li>
            `);
            changeSelectValue(result.product.variants[i].id, country)
            // changeSelectValue(variant_id)
            // location.reload();
          }
        }
      }
    });

    // Country dropdown change funciton
    $(document).on('change', 'select.single-option-selector', function(){
      var variant_title = $(this).val();
      fetch(`https://${url}.json`)
      .then(res=>res.json())
      .then(result=>{
        // console.log(result);
        for(var i = 0; i < result.product.variants.length; i++){
          if(result.product.variants[i].title == variant_title){
            // console.log(result.product.variants[i].id);
            window.history.pushState({ path: window.location.href }, '', `?variant=${result.product.variants[i].id}`);
            $(`.product-item-caption-price.${result.product.handle}`).html(`
              <li id="ProductPrice-product-template ${result.product.handle}" class="product-item-caption-price-current">
                <span class="money">
                  <span class="money" data-product-id="${result.product.id}">
                    <span class="money">
                      ₹ ${result.product.variants[i].price}
                    </span>
                  </span>
                </span>
              </li>
              <li id="ComparePrice-product-template ${result.product.handle}" class="product-item-caption-price-list"><span class="money">
                  <span class="bold-compare-at-money" data-product-id="${result.product.id}">
                    <span class="money">
                      ₹ ${result.product.variants[i].compare_at_price}
                    </span>
                  </span>
                </span>
              </li>
            `);
            // console.log('success..!!')
            // changeSelectValue(variant_id)
            // location.reload();
          }
        }
      });
    })
  }



  if(__st.p == 'searchresults'){
    $('div.list-view-items a').each(function(){
      var product_url = $(this).attr('href');
      var url = product_url.split("?")[0];
      fetch(`https://${__st.pageurl.split('/')[0]}/${url}.json`)
      .then(res=>res.json())
      .then(result=>{
        for(var i = 0; i < result.product.variants.length; i++){
          if(country == 'IN'){
            if(result.product.variants[i].title == 'IN'){
              $(`.list-view-item__price-column.${result.product.handle} s.product-price__price`).html(`<span class="money">₹ ${result.product.variants[i].compare_at_price}</span>`)
              $(`.list-view-item__price-column.${result.product.handle} s.product-price__price`).removeAttr('style');
              $(`.list-view-item__price-column.${result.product.handle} span.product-price__price.product-price__sale`).html(`<span class="money">₹ ${result.product.variants[i].price}</span>`)
              $(`.list-view-item__price-column.${result.product.handle} span.product-price__price.product-price__sale`).removeAttr('style')
            }
          }
          else{
            if(result.product.variants[i].title == 'OTHER'){
              $(`.list-view-item__price-column.${result.product.handle} s.product-price__price`).html(`<span class="money">₹ ${result.product.variants[i].compare_at_price}</span>`)
              $(`.list-view-item__price-column.${result.product.handle} s.product-price__price`).removeAttr('style');
              $(`.list-view-item__price-column.${result.product.handle} span.product-price__price.product-price__sale`).html(`<span class="money">₹ ${result.product.variants[i].price}</span>`)
              $(`.list-view-item__price-column.${result.product.handle} span.product-price__price.product-price__sale`).removeAttr('style')
            }
          }
        }
      });
    });
  }
})

  //   window
  //   .fetch("https://ip2c.org/self")
  //   .then((response) => response.text())
  //   .then((data) => {
  //     console.log(data);
  //     var country_data = String(data).split(";");
  //     var country = 'IN'
  //     console.log(country_data);
  //     var url = __st.pageurl.split("?")[0];
  //     fetch(`https://${url}.json`)
  //     .then(res=>res.json())
  //     .then(result=>{
  //       console.log(result);
  //       for(var i = 0; i < result.product.variants.length; i++){
  //         if(country == 'IN'){
  //           if(result.product.variants[i].title == 'IN'){
  //             var variant_id = result.product.variants[i].id;
  //             console.log(result.product.variants[i].id);
  //             // window.history.pushState({ path: window.location.href }, '', `?variant=${result.product.variants[i].id}`);
  //             console.log('success..!!')
  //             changeSelectValue(variant_id)
  //           }
  //         }
  //       }
  //     });
  //   })
  // }




  //   $.getJSON('https://jsonip.com/?callback=?').done(function(data) {
  //     var ip_address = window.JSON.parse(JSON.stringify(data, null, 2));
  //     $.ajax({
  //       url: `https://ipapi.co/${ip_address.ip}/json`,
  //       type: 'GET',
  //       success:function(country_data){
  //         console.log(country_data);
  //         var url = __st.pageurl.split("?")[0];
  //         fetch(`https://${url}.json`)
  //         .then(res=>res.json())
  //         .then(result=>{
  //           console.log(result);
  //           for(var i = 0; i < result.product.variants.length; i++){
  //             if(country_data.country == result.product.variants[i].title){
  //               var variant_id = result.product.variants[i].id;
  //               console.log(result.product.variants[i].id);
  //               // window.history.pushState({ path: window.location.href }, '', `?variant=${result.product.variants[i].id}`);
  //               console.log('success..!!')
  //               changeSelectValue(variant_id)
  //             }
  //           }
  //         });
  //       }
  //     });
  //   });
  

  function changeSelectValue(variant_id, country){
    console.log('function called..!!');
    $('.selection span span').attr('title', country);
//     $('.selection span span')[0].innerHTML = country;
    $('select.product-form__variants option').each(function(i){
      if($(this).val() != variant_id){
        if($(this).is("[selected]")){
          $('select.product-form__variants option')[i].removeAttribute("selected");
        }
      }else{
        $(this).attr("selected", "selected");
      }
      // localStorage['firstLoad'] = true;
  //       window.location.reload();
    })
  }